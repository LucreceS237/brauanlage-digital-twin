# states.py
from enum import Enum

class BrewState(Enum):
    EMERGENCY = "emergency"
    ERROR = "error"
    IDLE = "idle"
    MASHING = "mashing"
    LAUTERING = "lautering"
    BOILING = "boiling"
    COOLING = "cooling"
    FERMENTING = "fermenting"
    FINISHED = "finished"