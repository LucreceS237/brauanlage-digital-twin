# test_fsm.py – Unit-Tests für Zustandsübergänge, Not-Aus und Fehler
import pytest

from fsm import BrewStateMachine
from snapshot import ProcessSnapshot
from states import BrewState
from recipe import DEFAULT_RECIPE, StateSetpoints
from outputs import PlantOutputs


def fast_recipe() -> dict[BrewState, StateSetpoints]:
    """Kurze Zeiten für schnelle Tests."""
    return {
        **DEFAULT_RECIPE,
        BrewState.MASHING: StateSetpoints(temperature=65.0, duration_s=1),
        BrewState.LAUTERING: StateSetpoints(duration_s=1),
        BrewState.BOILING: StateSetpoints(temperature=100.0, duration_s=1),
        BrewState.FERMENTING: StateSetpoints(fermentation_temp=18.0, duration_s=1),
    }


def snap(**kwargs) -> ProcessSnapshot:
    defaults = {
        "emergency_stop": False,
        "start_requested": False,
        "acknowledge": False,
        "sensor_ok": True,
        "k1_temperature": 60.0,
        "k1_level": 80.0,
        "k3_temperature": 20.0,
        "flow_rate": 0.0,
    }
    defaults.update(kwargs)
    return ProcessSnapshot(**defaults)


@pytest.fixture
def fsm():
    return BrewStateMachine(recipe=fast_recipe())


class TestNormalTransitions:
    def test_initial_state_is_idle(self, fsm):
        assert fsm.state == BrewState.IDLE

    def test_stays_idle_without_start(self, fsm):
        fsm.update(snap(k1_temperature=60, k1_level=80), dt=0)
        assert fsm.state == BrewState.IDLE

    def test_stays_idle_with_low_level(self, fsm):
        fsm.update(snap(start_requested=True, k1_level=10), dt=0)
        assert fsm.state == BrewState.IDLE

    def test_idle_to_mashing(self, fsm):
        old, new = fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        assert old == BrewState.IDLE
        assert new == BrewState.MASHING
        assert fsm.last_transition_reason == "can_start_brewing"

    def test_mashing_to_lautering(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        old, new = fsm.update(snap(k1_temperature=65), dt=1)
        assert old == BrewState.MASHING
        assert new == BrewState.LAUTERING

    def test_lautering_waits_for_flow(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=0), dt=1)
        assert fsm.state == BrewState.LAUTERING

    def test_lautering_to_boiling(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        old, new = fsm.update(snap(flow_rate=1.0), dt=1)
        assert old == BrewState.LAUTERING
        assert new == BrewState.BOILING

    def test_boiling_to_cooling(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=1.0), dt=1)
        old, new = fsm.update(snap(k1_temperature=100), dt=1)
        assert old == BrewState.BOILING
        assert new == BrewState.COOLING

    def test_cooling_to_fermenting(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=1.0), dt=1)
        fsm.update(snap(k1_temperature=100), dt=1)
        old, new = fsm.update(snap(k3_temperature=20), dt=0)
        assert old == BrewState.COOLING
        assert new == BrewState.FERMENTING

    def test_fermenting_to_finished(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=1.0), dt=1)
        fsm.update(snap(k1_temperature=100), dt=1)
        fsm.update(snap(k3_temperature=20), dt=0)
        old, new = fsm.update(snap(k3_temperature=20), dt=1)
        assert old == BrewState.FERMENTING
        assert new == BrewState.FINISHED

    def test_full_process_path(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=1.0), dt=1)
        fsm.update(snap(k1_temperature=100), dt=1)
        fsm.update(snap(k3_temperature=20), dt=0)
        fsm.update(snap(k3_temperature=20), dt=1)
        assert fsm.state == BrewState.FINISHED


class TestEmergency:
    def test_emergency_from_mashing(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        old, new = fsm.update(snap(emergency_stop=True), dt=0)
        assert old == BrewState.MASHING
        assert new == BrewState.EMERGENCY
        assert fsm.last_transition_reason == "emergency_stop"

    def test_emergency_stays_without_acknowledge(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(emergency_stop=True), dt=0)
        fsm.update(snap(emergency_stop=False, acknowledge=False), dt=0)
        assert fsm.state == BrewState.EMERGENCY

    def test_emergency_to_idle_after_acknowledge(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(emergency_stop=True), dt=0)
        old, new = fsm.update(snap(acknowledge=True), dt=0)
        assert old == BrewState.EMERGENCY
        assert new == BrewState.IDLE

    def test_emergency_outputs_off(self, fsm):
        fsm.update(snap(emergency_stop=True), dt=0)
        assert fsm.outputs == PlantOutputs()


class TestError:
    def test_error_on_high_temperature(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        old, new = fsm.update(snap(k1_temperature=150), dt=0)
        assert old == BrewState.MASHING
        assert new == BrewState.ERROR

    def test_error_on_sensor_fault(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        old, new = fsm.update(snap(sensor_ok=False), dt=0)
        assert new == BrewState.ERROR

    def test_error_stays_with_acknowledge_while_fault_present(self, fsm):
        fsm.update(snap(k1_temperature=150), dt=0)
        fsm.update(snap(k1_temperature=150, acknowledge=True), dt=0)
        assert fsm.state == BrewState.ERROR

    def test_error_to_idle(self, fsm):
        fsm.update(snap(k1_temperature=150), dt=0)
        old, new = fsm.update(snap(k1_temperature=65, acknowledge=True), dt=0)
        assert old == BrewState.ERROR
        assert new == BrewState.IDLE

    def test_emergency_overrides_process_fault(self, fsm):
        fsm.update(snap(k1_temperature=150, emergency_stop=True), dt=0)
        assert fsm.state == BrewState.EMERGENCY


class TestTimerAndOutputs:
    def test_time_resets_on_state_change(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        assert fsm.time_in_state == 0.0
        fsm.update(snap(), dt=0.5)
        assert fsm.time_in_state == 0.5
        fsm.update(snap(), dt=1)
        assert fsm.state == BrewState.LAUTERING
        assert fsm.time_in_state == 0.0

    def test_mashing_outputs(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        assert fsm.outputs.heater_on is True
        assert fsm.outputs.pump_on is False

    def test_lautering_outputs(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        fsm.update(snap(), dt=1)
        assert fsm.outputs.pump_on is True
        assert fsm.outputs.valve_open is True

    def test_temperature_setpoint_follows_state(self, fsm):
        fsm.update(snap(start_requested=True, k1_temperature=60), dt=0)
        assert fsm.temperature_setpoint == 65.0
        fsm.update(snap(), dt=1)
        fsm.update(snap(flow_rate=1.0), dt=1)
        assert fsm.temperature_setpoint == 100.0
