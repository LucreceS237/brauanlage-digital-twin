# outputs.py
from dataclasses import dataclass

from states import BrewState


@dataclass(frozen=True)
class PlantOutputs:
    """Stellbefehle an die Anlage (SPS-Ausgänge) für den aktuellen Zustand."""

    heater_on: bool = False
    pump_on: bool = False
    valve_open: bool = False


# Zustand -> welche Aktoren aktiv sein sollen
STATE_OUTPUTS: dict[BrewState, PlantOutputs] = {
    BrewState.EMERGENCY: PlantOutputs(),
    BrewState.ERROR: PlantOutputs(),
    BrewState.IDLE: PlantOutputs(),
    BrewState.MASHING: PlantOutputs(heater_on=True),
    BrewState.LAUTERING: PlantOutputs(pump_on=True, valve_open=True),
    BrewState.BOILING: PlantOutputs(heater_on=True),
    BrewState.COOLING: PlantOutputs(),
    BrewState.FERMENTING: PlantOutputs(heater_on=True),
    BrewState.FINISHED: PlantOutputs(),
}


def outputs_for_state(state: BrewState) -> PlantOutputs:
    return STATE_OUTPUTS.get(state, PlantOutputs())
