# config.py – Grenzen und feste Schwellen (nicht rezeptabhängig)
from typing import Final

START_TEMP: Final[float] = 50           # °C Mindesttemperatur K1 vor Prozessstart
MIN_TEMP: Final[float] = 0              # °C Plausibilität
MAX_TEMP: Final[float] = 120            # °C
MIN_K1_LEVEL: Final[float] = 30         # % Mindestfüllstand zum Start
MIN_FLOW_RATE: Final[float] = 0.5       # z. B. L/min beim Lautern
MAX_LEVEL: Final[float] = 100           # %
