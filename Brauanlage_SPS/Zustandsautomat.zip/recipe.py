# recipe.py
from dataclasses import dataclass

from typing import TypeAlias

from states import BrewState


@dataclass(frozen=True)
class StateSetpoints:
    """Sollwerte für einen Prozessschritt."""

    temperature: float | None = None       # °C K1 (Heizen)
    duration_s: float | None = None        # Mindestdauer im Zustand
    cooling_target: float | None = None    # °C K3 (Kühlen)
    fermentation_temp: float | None = None # °C K3 (Gärung)


Recipe: TypeAlias = dict[BrewState, StateSetpoints]

# Standard-Rezept – pro Zustand eigene Parameter (ersetzt globale Einzelwerte)
DEFAULT_RECIPE: Recipe = {
    BrewState.IDLE: StateSetpoints(),
    BrewState.MASHING: StateSetpoints(temperature=65.0, duration_s=3600),
    BrewState.LAUTERING: StateSetpoints(duration_s=3600),
    BrewState.BOILING: StateSetpoints(temperature=100.0, duration_s=3600),
    BrewState.COOLING: StateSetpoints(cooling_target=25.0),
    BrewState.FERMENTING: StateSetpoints(fermentation_temp=18.0, duration_s=3600),
    BrewState.FINISHED: StateSetpoints(),
    BrewState.EMERGENCY: StateSetpoints(),
    BrewState.ERROR: StateSetpoints(),
}
