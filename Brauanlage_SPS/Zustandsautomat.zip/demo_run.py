# demo_run.py
import logging

from fsm import BrewStateMachine
from snapshot import ProcessSnapshot
from transition_log import setup_logging, log_transition


def snap(
    k1_temp: float,
    *,
    start: bool = False,
    emergency: bool = False,
    acknowledge: bool = False,
    sensor_ok: bool = True,
    k1_level: float = 80.0,
    k2_temp: float | None = None,
    k3_temp: float | None = None,
    flow: float = 0.0,
    pump_on: bool = False,
    valve_open: bool = False,
) -> ProcessSnapshot:
    """Hilfsfunktion für lesbare Demo-Snapshots."""
    return ProcessSnapshot(
        emergency_stop=emergency,
        start_requested=start,
        acknowledge=acknowledge,
        sensor_ok=sensor_ok,
        k1_temperature=k1_temp,
        k1_level=k1_level,
        k2_temperature=k2_temp if k2_temp is not None else k1_temp,
        k3_temperature=k3_temp if k3_temp is not None else k1_temp,
        flow_rate=flow,
        pump_on=pump_on,
        valve_open=valve_open,
    )


def run_steps(
    fsm: BrewStateMachine,
    steps: list[tuple[ProcessSnapshot, float]],
) -> None:
    for snapshot, dt in steps:
        old, new = fsm.update(snapshot, dt)
        log_transition(fsm, old, new)


setup_logging()

fsm = BrewStateMachine()

steps = [
    (snap(20, k1_level=10), 0),
    (snap(60), 0),
    (snap(60, start=True), 0),
    (snap(65), 3600),
    (snap(100, flow=0), 0),
    (snap(100, flow=1.0, valve_open=True), 3600),
    (snap(100), 3600),
    (snap(20, k3_temp=20), 0),
    (snap(20, k3_temp=20), 3600),
]

logging.getLogger("brauanlage.demo").info("=== Normaler Ablauf ===")
run_steps(fsm, steps)

logging.getLogger("brauanlage.demo").info("=== Not-Aus und Quittierung ===")
fsm_e = BrewStateMachine()
fsm_e.update(snap(60, start=True), 0)
run_steps(
    fsm_e,
    [
        (snap(65, emergency=True), 0),
        (snap(65, emergency=True, acknowledge=True), 0),
        (snap(65, acknowledge=True), 0),
    ],
)

logging.getLogger("brauanlage.demo").info("=== Prozessfehler (Temperatur) ===")
fsm_err = BrewStateMachine()
fsm_err.update(snap(60, start=True), 0)
run_steps(
    fsm_err,
    [
        (snap(150), 0),
        (snap(65, acknowledge=True), 0),
    ],
)

logging.getLogger("brauanlage.demo").info("=== Prozessfehler (Sensor) ===")
fsm_s = BrewStateMachine()
fsm_s.update(snap(60, start=True), 0)
run_steps(
    fsm_s,
    [
        (snap(65, sensor_ok=False), 0),
        (snap(65, acknowledge=True, sensor_ok=True), 0),
    ],
)
