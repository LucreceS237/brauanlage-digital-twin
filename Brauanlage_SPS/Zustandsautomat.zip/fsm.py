# fsm.py
"""
Zustandsautomat der Brauanlage.

Übersicht (Zustände, Guards, SPS-Bezug): siehe FSM.md im Projektroot.
"""
from states import BrewState
from recipe import DEFAULT_RECIPE, Recipe, StateSetpoints
from outputs import PlantOutputs, outputs_for_state
from snapshot import ProcessSnapshot
from fsm_types import StateTransition
from guards import (
    boiling_finished,
    can_leave_emergency,
    can_leave_error,
    can_start_brewing,
    cooled_down,
    emergency,
    fermentation_finished,
    lautering_finished,
    mash_finished,
    process_fault,
)


class BrewStateMachine:
    def __init__(self, recipe: Recipe | None = None) -> None:
        self.state: BrewState = BrewState.IDLE
        self._time_in_state: float = 0.0
        self.recipe: Recipe = recipe or DEFAULT_RECIPE
        self.last_transition_reason: str | None = None

    @property
    def time_in_state(self) -> float:
        """Verstrichene Zeit im aktuellen Zustand (Sekunden)."""
        return self._time_in_state

    @property
    def setpoints(self) -> StateSetpoints:
        """Aktuelle Sollwerte für den Prozesszustand (für Regelung / Anzeige)."""
        return self.recipe.get(self.state, StateSetpoints())

    @property
    def temperature_setpoint(self) -> float | None:
        """K1-Solltemperatur im aktuellen Zustand (z. B. für PID)."""
        sp = self.setpoints
        if sp.temperature is not None:
            return sp.temperature
        return sp.fermentation_temp

    @property
    def outputs(self) -> PlantOutputs:
        """Stellbefehle für den aktuellen Zustand (nach update() auswerten)."""
        return outputs_for_state(self.state)

    @property
    def heater_enabled(self) -> bool:
        """Kompatibel mit Regelung: Heizung freigegeben?"""
        return self.outputs.heater_on

    def _set_state(self, new_state: BrewState, reason: str) -> None:
        self.state = new_state
        self.last_transition_reason = reason

    def update(self, snapshot: ProcessSnapshot, dt: float = 1.0) -> StateTransition:
        old_state = self.state
        self.last_transition_reason = None

        if emergency(snapshot):
            if self.state != BrewState.EMERGENCY:
                self._set_state(BrewState.EMERGENCY, "emergency_stop")
                self._time_in_state = 0.0
            return old_state, self.state

        if self.state == BrewState.EMERGENCY:
            if can_leave_emergency(snapshot):
                self._set_state(BrewState.IDLE, "can_leave_emergency")
                self._time_in_state = 0.0
            return old_state, self.state

        if process_fault(snapshot):
            if self.state != BrewState.ERROR:
                self._set_state(BrewState.ERROR, "process_fault")
                self._time_in_state = 0.0
            return old_state, self.state

        if self.state == BrewState.ERROR:
            if can_leave_error(snapshot):
                self._set_state(BrewState.IDLE, "can_leave_error")
                self._time_in_state = 0.0
            return old_state, self.state

        if self.state == old_state:
            self._time_in_state += dt

        t = self._time_in_state
        sp = self.setpoints

        if self.state == BrewState.IDLE:
            if can_start_brewing(snapshot, self.recipe[BrewState.MASHING]):
                self._set_state(BrewState.MASHING, "can_start_brewing")

        elif self.state == BrewState.MASHING:
            if mash_finished(t, sp):
                self._set_state(BrewState.LAUTERING, "mash_finished")

        elif self.state == BrewState.LAUTERING:
            if lautering_finished(t, snapshot, sp):
                self._set_state(BrewState.BOILING, "lautering_finished")

        elif self.state == BrewState.BOILING:
            if boiling_finished(t, sp):
                self._set_state(BrewState.COOLING, "boiling_finished")

        elif self.state == BrewState.COOLING:
            if cooled_down(snapshot, sp):
                self._set_state(BrewState.FERMENTING, "cooled_down")

        elif self.state == BrewState.FERMENTING:
            if fermentation_finished(t, sp):
                self._set_state(BrewState.FINISHED, "fermentation_finished")

        if self.state != old_state:
            self._time_in_state = 0.0

        return old_state, self.state
